package net.auction.model.enums;

public enum UserType {
    ADMIN("Admin"),
    SELLER("Seller"),
    BIDDER("Bidder");

    private final String displayName;

    UserType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Additional methods or fields as needed

    @Override
    public String toString() {
        return "UserType{" +
                "displayName='" + displayName + '\'' +
                '}';
    }
}
