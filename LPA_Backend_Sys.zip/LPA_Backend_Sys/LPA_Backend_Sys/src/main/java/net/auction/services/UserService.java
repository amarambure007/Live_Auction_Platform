package net.auction.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import net.auction.model.entity.User;
import net.auction.model.enums.UserType;
import net.auction.repo.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getAllUsers() {
        try {
            return userRepository.findAll();
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while retrieving all users", e);
        }
    }

    public List<User> getAdminUsers() {
        try {
            return userRepository.findByUserType(UserType.ADMIN);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while retrieving admin users", e);
        }
    }

    public List<User> getCustomerUsers() {
        try {
            return userRepository.findByUserType(UserType.BIDDER);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while retrieving customer users", e);
        }
    }

    public Optional<User> getUserByUsername(String username) {
        try {
            return Optional.ofNullable(userRepository.findByUsername(username));
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while retrieving user by username: " + username, e);
        }
    }

    @Transactional
    public User saveOrUpdateUser(User user) {
        try {
            return userRepository.save(user);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while saving/updating user", e);
        }
    }

    public void deleteUser(Long userId) {
        try {
            userRepository.deleteById(userId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error while deleting user with ID: " + userId, e);
        }
    }
}
