package net.auction.model.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemName;
    private String description;
    private BigDecimal startingBid;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String category;
    private double currentBid;

    @Override
	public String toString() {
		return "Item [id=" + id + ", itemName=" + itemName + ", description=" + description + ", startingBid="
				+ startingBid + ", startTime=" + startTime + ", endTime=" + endTime + ", category=" + category
				+ ", currentBid=" + currentBid + ", seller=" + seller + ", getCurrentBid()=" + getCurrentBid()
				+ ", getCategory()=" + getCategory() + ", getId()=" + getId() + ", getItemName()=" + getItemName()
				+ ", getDescription()=" + getDescription() + ", getStartingBid()=" + getStartingBid()
				+ ", getStartTime()=" + getStartTime() + ", getEndTime()=" + getEndTime() + ", getSeller()="
				+ getSeller() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public Item(Long id, String itemName, String description, BigDecimal startingBid, LocalDateTime startTime,
			LocalDateTime endTime, String category, double currentBid, User seller) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.description = description;
		this.startingBid = startingBid;
		this.startTime = startTime;
		this.endTime = endTime;
		this.category = category;
		this.currentBid = currentBid;
		this.seller = seller;
	}

	public double getCurrentBid() {
		return currentBid;
	}

	public void setCurrentBid(double currentBid) {
		this.currentBid = currentBid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@ManyToOne
    @JoinColumn(name = "seller_id")
    private User seller;

    // Constructors, getters, setters, etc.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getStartingBid() {
        return startingBid;
    }

    public void setStartingBid(BigDecimal startingBid) {
        this.startingBid = startingBid;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public User getSeller() {
        return seller;
    }

    public void setSeller(User seller) {
        this.seller = seller;
    }
}
