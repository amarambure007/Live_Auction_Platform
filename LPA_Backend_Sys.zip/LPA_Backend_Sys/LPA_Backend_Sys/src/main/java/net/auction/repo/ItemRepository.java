package net.auction.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import net.auction.model.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

	List<Item> findByItemName(String itemName);
	
	List<Item> findByCategory(String category);

    List<Item> findByCurrentBidGreaterThan(double minBidAmount);

    List<Item> findAll();

    Optional<Item> findById(Long itemId);  // Corrected the return type to Optional<Item>
}
