package net.auction.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

import net.auction.model.entity.Bid;

public interface BidRepository extends JpaRepository<Bid, Long> {
    List<Bid> findByItemId(Long itemId);
    List<Bid> findByBidderId(Long bidderId);
    Bid findTopByItemIdOrderByAmountDesc(Long itemId);

    // You can add additional custom queries if needed
}
