package net.auction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import net.auction.model.entity.User;
import net.auction.model.enums.UserType;
import net.auction.repo.UserRepository;

@Controller
@RequestMapping("/login")
public class LoginRegistrationController {

    @Autowired
    private UserRepository userRepository;

    // Endpoint to display the login page
    @GetMapping
    public String showLoginPage() {
        return "login"; // Return the name of your login HTML file
    }

    // Endpoint to handle user authentication
    @PostMapping("/authenticate")
    public String authenticateUser(@RequestParam String username,
                                   @RequestParam String password,
                                   Model model) {
        // Perform authentication logic (e.g., check credentials in the database)
        User user = userRepository.findByUsernameAndPassword(username, password);

        if (user != null) {
            model.addAttribute("user", user);
            return redirectBasedOnUserType(user.getUserType());
        } else {
            model.addAttribute("error", "Invalid credentials. Please try again.");
            return "login"; // Redirect back to the login page with an error message
        }
    }

    // Helper method to redirect based on user type after successful authentication
    private String redirectBasedOnUserType(UserType userType) {
        if (isUserType(userType, UserType.ADMIN)) {
            return "redirect:/admin-dashboard";
        } else if (isUserType(userType, UserType.SELLER)) {
            return "redirect:/seller-dashboard";
        } else if (isUserType(userType, UserType.BIDDER)) {
            return "redirect:/bidder-dashboard";
        } else {
            return "redirect:/dashboard"; // Default redirect for unknown user types
        }
    }

    // Helper method to check if the user has a specific user type
    private boolean isUserType(UserType actualType, UserType expectedType) {
        return actualType != null && actualType.equals(expectedType);
    }
}
