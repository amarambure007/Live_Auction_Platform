package net.auction.model.enums;

public enum BidStatus {
    ACTIVE("Active"),
    WON("Won"),
    LOST("Lost"),
    PROCESSED("Processed");

    private final String displayName;

    BidStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Additional methods or fields as needed

    @Override
    public String toString() {
        return "BidStatus{" +
                "displayName='" + displayName + '\'' +
                '}';
    }
}
