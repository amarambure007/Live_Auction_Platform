package net.auction.model.entity;

import jakarta.persistence.*;

@Entity
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double amount;

    @ManyToOne
    private Item item;

    @Override
	public String toString() {
		return "Bid [id=" + id + ", amount=" + amount + ", item=" + item + ", bidder=" + bidder + ", getId()=" + getId()
				+ ", getAmount()=" + getAmount() + ", getItem()=" + getItem() + ", getBidder()=" + getBidder()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public Bid(Long id, double amount, Item item, User bidder) {
		super();
		this.id = id;
		this.amount = amount;
		this.item = item;
		this.bidder = bidder;
	}

	@ManyToOne
    private User bidder;

    // Constructors, getters, setters, etc.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public User getBidder() {
        return bidder;
    }

    public void setBidder(User bidder) {
        this.bidder = bidder;
    }

    // Additional method to set bidderName directly
    public void setBidderName(String bidderName) {
        if (bidder == null) {
            bidder = new User(id, bidderName, bidderName, bidderName, bidderName, bidderName);
        }
        bidder.setUsername(bidderName);
    }
}
